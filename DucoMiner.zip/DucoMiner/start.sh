clear
echo ""
echo "------------------------"
echo "|                      |"
echo "|      DuinoMiner      |"
echo "|         V1.0         |"
echo "|                      |"
echo "------------------------"
echo ""
python3 miner.py
